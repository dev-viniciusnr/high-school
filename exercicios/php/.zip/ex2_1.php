<!DOCTYPE html>
<html>
<head>
	<title>Ao cubo</title>
</head>
<body>
	<form method="POST" action="ex2_2.php">
		<input type="number" name="number">
		<input type="submit" value="enviar">
	</form>
</body>
</html>