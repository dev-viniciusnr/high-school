<!DOCTYPE html>
<html>
<head>
	<title>Tabuada</title>
</head>
<body>
	<form method="POST" action="ex1_2.php">
	<input type="text" name="tabu">
	<input type="submit" name="btn" value="enviar">
	</form>
</body>
</html>